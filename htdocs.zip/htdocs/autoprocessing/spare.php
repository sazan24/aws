<?php
// Remove the restrictions
set_time_limit(0); // No time limits (realistically 600 seconds)
ini_set("memory_limit", "128M");

// Fetch the content from the URL
$homepage = file_get_contents(
    "http://www.almhuette-raith.at/apache-log/access.log",
    false,
    null,
    0,
    20000000
);

// Divide the content into lines
$arr = explode("\n", $homepage);

// Drop the last line
array_pop($arr);

// Drop the first line
array_shift($arr);

// Connect to the database
$servername = "localhost"; // Server address
$username = "root"; // Database server username
$password = ""; // Database server password
$dbname = "autoprocessing"; // Database name

// Create a database connection
$mysqli = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// SQL query to create the 'collection' table
$sqlCreateTable = "CREATE TABLE IF NOT EXISTS collection (
    ID INT PRIMARY KEY,
    IP VARCHAR(15),
    Log TEXT
);";

// Execute the query
if ($mysqli->query($sqlCreateTable) === TRUE) {
    echo "<b>Table 'collection' created successfully</b><br>";
} else {
    echo "<b>Error creating table: " . $mysqli->error . "</b><br>";
}

// Counter for ID
$id = 0;

// Counter for successful inserts
$successCount = 0;

foreach ($arr as $k => $line) {
    $line = str_replace("'", "\'", $line); // Escape apostrophes
    preg_match('/^([\d\.]+) \S+ \S+ \[.*\] "(.*)".*$/', $line, $matches); // Extract IP addresses and log data

    if (count($matches) == 3) {
        $ip = $matches[1];
        $log = $matches[2];
        $sqlstr = "INSERT INTO collection (ID, IP, Log) VALUES ('" . $id . "', '" . $ip . "', '" . $log . "');";
        if ($mysqli->query($sqlstr)) {
            $successCount++;
        }
        $id++;
    }
}

// Output the success message
echo "<b>Successfully inserted " . $successCount . " records into the 'collection' table</b><br>";

// Close the database connection
$mysqli->close();
?>