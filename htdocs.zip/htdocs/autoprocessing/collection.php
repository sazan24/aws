<?php
set_time_limit(0);
ini_set("memory_limit", "512M");

echo "<html>\n";
echo "<body>\n";

echo "<h1>Info page</h1>\n";

// Get file
$homepage = file_get_contents('http://www.almhuette-raith.at/apache-log/access.log', FALSE, NULL, 0, 200000000);

// Divide the content into lines
$arr = explode("\n", $homepage);

// Drop the last line
array_pop($arr);

// Drop the first line
array_shift($arr);

// Connect to the database
$servername = "localhost"; // Server address
$username = "root"; // Database server username
$password = ""; // Database server password
$dbname = "autoprocessing"; // Database name

// Create a database connection
$mysqli = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// SQL query to check if the 'collection' table exists
$tableExistsQuery = "SHOW TABLES LIKE 'collection';";
$tableExistsResult = $mysqli->query($tableExistsQuery);

if ($tableExistsResult->num_rows == 0) {
    // Table does not exist, create it
    $sqlCreateTable = "CREATE TABLE collection (
                           ID INT PRIMARY KEY,
                           IP VARCHAR(15),
                           Log TEXT);";

    // Execute the query
    if ($mysqli->query($sqlCreateTable) === TRUE) {
        echo "<b>Table 'collection' created successfully</b><br>";
    } else {
        echo "<b>Error creating table:</b> " . $mysqli->error . "<br>";
    }
}

// Counter for ID
$id = 0;

// Counter for successful inserts
$successCount = 0;

foreach ($arr as $k => $line) {
    $line = str_replace("'", "\'", $line); // Escape apostrophes
    preg_match('/^([\d\.]+) \S+ \S+ \[.*\] "(.*)".*$/', $line, $matches); // Extract IP addresses and log data

    if (count($matches) == 3) {
        $ip = $matches[1];
        $log = $matches[2];

        // Check if the IP already exists in the table
        $checkExistingQuery = "SELECT * FROM collection WHERE IP = '$ip';";
        $existingResult = $mysqli->query($checkExistingQuery);

        if ($existingResult->num_rows == 0) {
            // IP does not exist, insert the record
            $sqlstr = "INSERT INTO collection (ID, IP, Log) VALUES ('$id', '$ip', '$log');";
            if ($mysqli->query($sqlstr)) {
                $successCount++;
            }
            $id++;
        }
    }
}

// Output the success message
echo "<b>Successfully inserted " . $successCount . " records into the 'collection' table</b><br><br>";

// Close the database connection
$mysqli->close();
?>