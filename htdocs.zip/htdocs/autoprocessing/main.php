<?php
// Remove the restrictions
set_time_limit(0); // No time limits (realistically 600 seconds)
ini_set("memory_limit", "128M");

echo "<html>\n";
echo "<body>\n";

echo "<h1>Info page</h1>\n";

// Fetch the content from the URL
$homepage = file_get_contents(
    "http://www.almhuette-raith.at/apache-log/access.log",
    false,
    null,
    0,
    2000000
);

// Divide the content into lines
$arr = explode("\n", $homepage);

// Drop the last line
array_pop($arr);

// Drop the first line
array_shift($arr);

// Connect to the database
$servername = "localhost"; // Server address
$username = "root"; // Database server username
$password = ""; // Database server password
$dbname = "autoprocessing"; // Database name

// Create a database connection
$mysqli = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// SQL query to drop the 'collection' table if it exists
$sqlDropTable = "DROP TABLE IF EXISTS collection;";

// Execute the query to drop the table
if ($mysqli->query($sqlDropTable) === TRUE) {
    echo "Table 'collection' dropped successfully<br>";
} else {
    echo "Error dropping table: " . $mysqli->error . "<br>";
}

// SQL query to create the 'collection' table
$sqlCreateTable = "CREATE TABLE IF NOT EXISTS collection (
                       ID INT PRIMARY KEY,
                       IP VARCHAR(15),
                       Log TEXT
);";

// Execute the query to create the table
if ($mysqli->query($sqlCreateTable) === TRUE) {
    echo "Table 'collection' created successfully<br>";
} else {
    echo "Error creating table: " . $mysqli->error . "<br>";
}

// Counter for ID
$id = 0;

// Counter for successful inserts
$successCount = 0;

foreach ($arr as $k => $line) {
    $line = str_replace("'", "\'", $line); // Escape apostrophes
    preg_match('/^([\d\.]+) \S+ \S+ \[.*\] "(.*)".*$/', $line, $matches); // Extract IP addresses and log data

    if (count($matches) == 3) {
        $ip = $matches[1];
        $log = $matches[2];
        $sqlstr = "INSERT INTO collection (ID, IP, Log) VALUES ('" . $id . "', '" . $ip . "', '" . $log . "');";
        if ($mysqli->query($sqlstr)) {
            $successCount++;
        }
        $id++;
    }
}

// Output the success message
echo "Successfully inserted " . $successCount . " records into the 'collection' table<br><br>";

// Close the database connection
$mysqli->close();

$RA = "46.125.249.79"; // IP

$ch = curl_init("http://ip-api.com/json/" . $RA);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HEADER, false);
$res = curl_exec($ch);

if ($res === false) {
    echo "cURL Error: " . curl_error($ch) . "<br>";
} else {
    $res = json_decode($res, true);

    echo "<b>2. Нижче наведена більше детальна інформація про IP-адресу '$RA':</b><br>";
    // Print each key-value pair on a new line
    foreach ($res as $key => $value) {
        echo "[$key] => $value<br>";
    }
    echo "<br>";
}
curl_close($ch);

echo "<b>3. Продемонструємо діаграму розподілу всього скачаного від IP-адреси '$RA':</b><br>";
echo "<img src='./diagram.php'>";

echo "</body>\n";
echo "</html>\n";
?>
