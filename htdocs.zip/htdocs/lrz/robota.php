<!DOCTYPE HTML>
<!--
    Halcyonic by HTML5 UP
    html5up.net | @ajlkn
    Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
    <head>
        <title>Працевлаштування на ІФ ЛРЗ</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
        <link rel="stylesheet" href="assets/css/main.css" />
        <!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
        <link rel="icon" type="image/x-icon" href="logo.png">
    </head>
<body class="subpage">
    <div id="page-wrapper">
        <!-- Header -->
        <div id="header-wrapper">
            <header id="header" class="container">
                <div class="row">
                    <div class="12u">
                        <!-- Logo -->
                        <h1 id="logo"><a href="index.html">Івано-Франківський ЛРЗ</a></h1>
                        <!-- Nav -->
                        <nav id="nav">
                            <a href="poslugy.html">Наші послуги</a>
                            <a href="robota.php">Працевлаштування</a>
                            <a href="pro_zavod.html">Про завод</a>
                            <a href="php_form.html">PHP-форма</a>
                        </nav>
                    </div>
                </div>
            </header>
        </div>
        <!-- Content -->
        <div id="content-wrapper">
            <div id="content">
                <div class="container">
                    <div class="row">
                        <div class="9u 12u(mobile)">
                            <!-- Main Content -->
                            <section>
                                <header>
                                    <h2>Працевлаштування</h2>
                                    <h3>Анкета для заповнення власних даних</h3>
                                </header>
                                <form action="robota.php" method="post">
                                    <p>Заповніть заявку для подання у відділ кадрів</p>
                                    <input type="text" name="surname" placeholder="Прізвище">
                                    <input type="text" name="my_name" placeholder="Ім'я">
                                    <input type="text" name="father_name" placeholder="По-батькові">
                                    <br>
                                    <br>
                                    <input type="number" name="age" placeholder="Вік">
                                    <input type="text" name="job" placeholder="Професія">
                                    <br>
                                    <br>
                                    <input id="send" type="submit" value="Надіслати">
                                </form>
<?php 
    require_once "config.php";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $pri = $_POST["surname"] ?? "";
        $ima = $_POST["my_name"] ?? "";
        $bat = $_POST["father_name"] ?? "";
        $vik = $_POST["age"] ?? "";
        $pro = $_POST["job"] ?? "";

        $database = "mywebkyi_db";

        if(isset($pri) && isset($ima) && isset($bat) && isset($vik) && isset($pro)) {
            $mysqli = connectDB($database);
            // Check connection
            if($mysqli === false){
                die("ERROR: Could not connect. " . $mysqli->connect_error);
            }

            // Attempt insert query execution
            $sql = "INSERT INTO `viddil_kadriv`(`surname`, `my_name`, `father_name`, `age`, `job`) 
                    VALUES ('$pri', '$ima', '$bat', '$vik', '$pro')";
            # echo $sql;
            if($mysqli->query($sql) === true){
                echo "Записи додані успішно";
            } else{
                echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
            }
            
            // Close connection
            $mysqli->close();
        }
    }
?>
                                <style>
                                    table {
                                        border-collapse: separate;
                                        text-indent: initial;
                                        border-spacing: 2px;
                                    }
                                    .tab_third table {
                                        border: solid #039;
                                        text-align: center;
                                    }
                                    .tab_third th {
                                        font-weight: bold;
                                        font-size: 25px;
                                        color: lime;
                                        padding: 10px 15px;
                                        background: grey;
                                    }
                                    .tab_third td {
                                        color: yellow;
                                        border-top: 1px solid #e8edff;
                                        padding: 10px 15px;
                                        background: grey;
                                    }
                                </style>
                            </section>
                        </div>
                        <div class="3u 12u(mobile)">
                            <!-- Sidebar -->
                            <section>
                                <header>
                                    <h2>База Даних</h2>
                                </header>
                                <ul class="link-list">
                                    <li><a href="#">ПІБ</a></li>
                                    <li><a href="#">Дата народження</a></li>
                                    <li><a href="#">Місце проживання</a></li>
                                    <li><a href="#">Ступінь освіти</a></li>
                                    <li><a href="#">Стаж робити за фахом</a></li>
                                    <li><a href="discloser.php">Професія</a></li>
                                </ul>
                            </section>
                            <section>
                                <header>
                                    <h2>Виникли запитання?</h2>
                                </header>
                                <p> Зв'яжіться з нами одним із наступних способів: </p>
                                <ul class="link-list">
                                    <li><a href="#">info@lrz.if.ua</a> Електронна пошта</li>
                                    <li><a href="#">+38(067)475-35-60</a> Відділ кадрів</li>
                                </ul>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer -->
        <div id="footer-wrapper">
            <footer id="footer" class="container">
                <div class="row">
                    <div class="8u 12u(mobile)">
                        <!-- Links -->
                        <section>
                            <h2 style="color: DarkRed;">Контактна інформація:</h2>
                            <div>
                                <div class="row">
                                    <div class="3u 12u(mobile)">
                                        <ul class="link-list last-child">
                                            <pre style="color: DarkSlateBlue;">
76000, Україна, м. Івано-Франківськ, вул. Залізнична, 22
Приймальня: тел./факс +38(0342)53-23-70, +38(067)475-39-39
Відділ збуту: тел./факс +38(0342)55-95-87
Відділ постачання: тел./факс +38(0342)55-95-84
Відділ кадрів: тел. +38(067)475-35-60
E-mail: info@lrz.if.ua
                                            </pre>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <div class="4u 12u(mobile)">
                        <!-- Blurb -->
                        <section>
                            <h2>Місцезнаходження ІФ ЛРЗ</h2>
                            <p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3680.7054856515992!2d24.725038703729854!3d48.92470350982753!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4730c16e26e0ed13%3A0x93d4a9dba65b9036!2z0JDQoiAi0IbQstCw0L3Qvi3QpNGA0LDQvdC60ZbQstGB0YzQutC40Lkg0LvQvtC60L7QvNC-0YLQuNCy0L7RgNC10LzQvtC90YLQvdC40Lkg0LfQsNCy0L7QtCI!5e0!3m2!1suk!2sua!4v1636489899893!5m2!1suk!2sua" width="500" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe></p>
                        </section>
                    </div>
                </div>
            </footer>
        </div>
        <!-- Copyright -->
        <div id="copyright">
            &copy; Untitled. All rights reserved. | Design: <a href="http://html5up.net">HTML5 UP</a>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.dropotron.min.js"></script>
    <script src="assets/js/skel.min.js"></script>
    <script src="assets/js/skel-viewport.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
