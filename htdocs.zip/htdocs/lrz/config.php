<?php 
	$mysqli = false;

	function connectDB($database) {
		global $mysqli;
		
		$servername = "localhost";
		$username = "mywebkyi_hosting";
		$password = "=nTge2r*cb+(";

		$mysqli = new mysqli($servername, $username, $password, $database);
		return $mysqli;
	}

	function closeDB() {
		global $mysqli;
		$mysqli -> close();
	}

	function getData($database, $table) {
		global $mysqli;
		connectDB($database);
		$result = $mysqli -> query("SELECT * FROM $table");
		return resultToArray ($result);
	}

	function resultToArray($result) {
		$array = array();
		while (($row = $result -> fetch_assoc()) != false)
			$array[] = $row;
		return $array;
	}   
?>
