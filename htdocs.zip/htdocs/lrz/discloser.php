<!DOCTYPE HTML>
<!--
    Halcyonic by HTML5 UP
    html5up.net | @ajlkn
    Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
    <head>
        <title>Працевлаштування на ІФ ЛРЗ</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <!--[if lte IE 8]>
        <script src="assets/js/ie/html5shiv.js"></script>
        <![endif]-->
        <link rel="stylesheet" href="assets/css/main.css" />
        <!--[if lte IE 9]>
        <link rel="stylesheet" href="assets/css/ie9.css" />
        <![endif]-->
    </head>
    <body class="subpage">
        <div id="page-wrapper">
            <!-- Header -->
            <div id="header-wrapper">
                <header id="header" class="container">
                    <div class="row">
                        <div class="12u">
                            <!-- Logo -->
                            <h1>
                                <a href="index.html">Івано-Франківський ЛРЗ</a>
                            </h1>
                            <!-- Nav -->
                            <nav id="nav">
                                <a href="poslugy.html">Наші послуги</a>
                                <a href="robota.php">Працевлаштування</a>
                                <a href="pro_zavod.html">Про завод</a>
                                <a href="php_form.php">PHP-форма</a>
                            </nav>
                        </div>
                    </div>
                </header>
            </div>
            <!-- Content -->
            <div id="content-wrapper">
                <div id="content">
                    <div class="container">
                        <div class="row">
                            <div class="9u 12u(mobile)">
                                <!-- Main Content -->
                                <section>
                                    <header>
                                        <h2>Зворотня сторона медалі</h2>
                                        <h3>База даних кандидатів на вакантні місця</h3>
<?php
    require_once "config.php";

    $info = getData("mywebkyi_db", "viddil_kadriv");

    echo "<div class='tab_third'>"; 
    echo "<table>";
    $i = 0;
    foreach ($info as $info_value) {
        if ($i == 0) {
            echo "<tr>";
            foreach ($info_value as $key => $value) {
                echo "<th><div align='center'>" . htmlspecialchars($key) . "</div></th>";
            }
            echo "<th><div align='center' class='purple-text'>Редагувати</div></th>";
            echo "<th><div align='center' class='purple-text'>Видалити</div></th>";
            echo "</tr>";
            $i++;
        }
        echo "<tr>";
        foreach ($info_value as $key => $value) {
            echo "<td><div align='center'>" . htmlspecialchars($value) . "</div></td>";
        }
        $record_id = htmlspecialchars($info_value['ID']); // Отримуємо ID запису з даних
        echo "<td>
              <div align='center'>
              <a href='update.php?id=$record_id'> <img src='images/edit.png' width='25' height='25' alt='Edit'> </a>
              </div>
              </td>";
        echo "<td>
              <div align='center'>
              <a href='delete.php?id=$record_id'> <img src='images/del.png' width='25' height='25' alt='Delete'> </a>
              </div>
              </td>";
        echo "</tr>";
    } 
    echo "</table>"; 
    echo "</div>";
?>
                                    </header>
                                </section>
                                <style>
                                    table {
                                        border-collapse: separate;
                                        text-indent: initial;
                                        border-spacing: 2px;
                                    }
                                    .tab_third table {
                                        border: solid #039;
                                        text-align: center;
                                    }
                                    .tab_third th {
                                        font-weight: bold;
                                        font-size: 25px;
                                        color: lime;
                                        padding: 10px 15px;
                                        background: grey;
                                    }
                                    .tab_third td {
                                        color: yellow;
                                        border-top: 1px solid #e8edff;
                                        padding: 10px 15px;
                                        background: grey;
                                    }
                                    .purple-text {
                                        color: purple;
                                    }
                                </style>
                            </div>
                            <div class="3u 12u(mobile)">
                                <!-- Sidebar -->
                                <section>
                                    <header>
                                        <h2>База Даних</h2>
                                    </header>
                                    <ul class="link-list">
                                        <li>
                                            <a href="#">ПІБ</a>
                                        </li>
                                        <li>
                                            <a href="#">Дата народження</a>
                                        </li>
                                        <li>
                                            <a href="#">Місце проживання</a>
                                        </li>
                                        <li>
                                            <a href="#">Ступінь освіти</a>
                                        </li>
                                        <li>
                                            <a href="#">Стаж робити за фахом</a>
                                        </li>
                                        <li>
                                            <a href="#">Професія</a>
                                        </li>
                                    </ul>
                                </section>
                                <section>
                                    <header>
                                        <h2>Виникли запитання?</h2>
                                    </header>
                                    <p> Зв'яжіться з нами одним із наступних способів: </p>
                                    <ul class="link-list">
                                        <li>
                                            <a href="#">info@lrz.if.ua</a> Електронна пошта
                                        </li>
                                        <li>
                                            <a href="#">+38(067)475-35-60</a> Відділ кадрів
                                        </li>
                                    </ul>
                                </section>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <div id="footer-wrapper">
                <footer id="footer" class="container">
                    <div class="row">
                        <div class="8u 12u(mobile)">
                            <!-- Links -->
                            <section>
                                <h2 style="color: DarkRed;">Контактна інформація:</h2>
                                <div>
                                    <div class="row">
                                        <div class="3u 12u(mobile)">
                                            <ul class="link-list last-child">
                                                <pre style="color: DarkSlateBlue;">76000, Україна, м. Івано-Франківськ, вул. Залізнична, 22
 
Приймальня: тел./факс +38(0342)53-23-70, +38(067)475-39-39

Відділ збуту: тел./факс +38(0342)55-95-87

Відділ постачання: тел./факс +38(0342)55-95-84

Відділ кадрів: тел. +38(067)475-35-60

E-mail: info@lrz.if.ua</pre>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                        <div class="4u 12u(mobile)">
                            <!-- Blurb -->
                            <section>
                                <h2>Місцезнаходження ІФ ЛРЗ</h2>
                                <p>
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3680.7054856515992!2d24.725038703729854!3d48.92470350982753!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4730c16e26e0ed13%3A0x93d4a9dba65b9036!2z0JDQoiAi0IbQstCw0L3Qvi3QpNGA0LDQvdC60ZbQstGB0YzQutC40Lkg0LvQvtC60L7QvNC-0YLQuNCy0L7RgNC10LzQvtC90YLQvdC40Lkg0LfQsNCy0L7QtCI!5e0!3m2!1suk!2sua!4v1636489899893!5m2!1suk!2sua" width="500" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                </p>
                            </section>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- Copyright -->
            <div id="copyright"> &copy; Untitled. All rights reserved. | Design: <a href="http://html5up.net">HTML5 UP</a>
            </div>
        </div>
        <!-- Scripts -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/skel.min.js"></script>
        <script src="assets/js/skel-viewport.min.js"></script>
        <script src="assets/js/util.js"></script>
        <!--[if lte IE 8]>
        <script src="assets/js/ie/respond.min.js"></script>
        <![endif]-->
        <script src="assets/js/main.js"></script>
    </body>
</html>