<?php 
	include "config.php";
	$ID = $_GET['id'] ?? "";
	$database = "mywebkyi_db";

	$mysqli = connectDB($database);

	// Check connection
	if(!$mysqli){
		die("ERROR: Could not connect. " . $mysqli->connect_error);
	}
		 
	// Attempt insert query execution
	$sql = "DELETE FROM `viddil_kadriv` WHERE ID='$ID'";
	if($mysqli -> query($sql) === true){
?>
<script>
	window.location = "robota.php";
</script>
<?php
	} else{
		echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
	}
		 
	// Close connection
	$mysqli->close();
?>