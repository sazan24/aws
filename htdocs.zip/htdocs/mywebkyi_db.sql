-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Час створення: Чрв 02 2024 р., 15:50
-- Версія сервера: 10.4.28-MariaDB
-- Версія PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База даних: `mywebkyi_db`
--

-- --------------------------------------------------------

--
-- Структура таблиці `viddil_kadriv`
--

CREATE TABLE `viddil_kadriv` (
  `ID` int(11) NOT NULL,
  `surname` varchar(15) NOT NULL,
  `my_name` varchar(15) NOT NULL,
  `father_name` varchar(15) NOT NULL,
  `age` int(11) NOT NULL,
  `job` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Дамп даних таблиці `viddil_kadriv`
--

INSERT INTO `viddil_kadriv` (`ID`, `surname`, `my_name`, `father_name`, `age`, `job`) VALUES
(1, '', '', '', 0, '<script>alert(\"Hello!\")</scrip'),
(2, '', '', '<sctipt>alert(\"', 0, ''),
(3, 'Зозуля', 'Роман', 'Андрійович', 48, 'Металург'),
(4, 'Коржак', 'Степан', 'Андрійович', 21, 'Дизайнер'),
(5, 'Василенко', 'Єлизавета', 'Вікторівна', 24, 'Машиніст'),
(6, '', '', 'SELECT * FROM', 0, ''),
(7, 'Тетерваковський', 'Василь', 'Андрійович', 31, 'Тесляр'),
(8, 'Костюченко', 'Віталій', 'Сергійович', 22, 'Інженер'),
(9, 'Сахній', 'Назар', 'Романович', 43, 'Інженер'),
(10, 'Сахній', 'Роман', 'Тарасович', 54, 'Інженер');

--
-- Індекси збережених таблиць
--

--
-- Індекси таблиці `viddil_kadriv`
--
ALTER TABLE `viddil_kadriv`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT для збережених таблиць
--

--
-- AUTO_INCREMENT для таблиці `viddil_kadriv`
--
ALTER TABLE `viddil_kadriv`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
